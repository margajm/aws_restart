names ={"cary", "nikki", "ana"}
for name in names :
    newName = capitalize(name)
    print(newName)