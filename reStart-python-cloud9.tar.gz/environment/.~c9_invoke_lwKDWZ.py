milistaMercado = ["apio","ajos","kion","zanahoria"]
print(milistaMercado)
print(type(milistaMercado))

print(milistaMercado[0])
print(milistaMercado[1])
print(milistaMercado[2])

milistaMercado[2] = "beterraga"
print(milistaMercado)

miTupladulce = ("mazamorra", "arroz con leche", "gelatina")
print(miTupladulce)
print(type(miTupladulce))

print(miTupladulce[0])
print(miTupladulce[1])
print(miTupladulce[2])

misPostresDiccionario = {
    "Ana":"mazamorra",
    "Juan":"arroz con leche",
    "Angel":"gelatina"
    }
print(misPostresDiccionario)
print(type(misPostresDiccionario))


print(misPostresDiccionario["Ana"])
print(misPostresDiccionario["Juan"])
print(misPostresDiccionario["Angel"])

misPostresDiccionario ["Pepe"] = "cheescake"
print(misPostresDiccionario)
