name = input("ingrese su nombre:")
print(name)

