miListaMixta = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]

for item in miListaMixta:
    print("{} es de tipo de dato".format(item,type(item)))
    
    45 int
    290578 int